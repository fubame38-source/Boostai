const express = require("express");
const cors = require("cors");
const Anthropic = require("@anthropic-ai/sdk");

const app = express();
app.use(cors());
app.use(express.json());

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

app.get("/", (req, res) => res.json({ status: "Pulse API çalışıyor 🚀" }));

app.post("/analyze", async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: "URL gerekli" });
  try {
    const analysis = await claudeAnalyze(url);
    res.json({ success: true, ...analysis });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

async function claudeAnalyze(url) {
  const prompt = `Sen uzman bir sosyal medya viral içerik analistisin. Video URL: ${url}

Bu videonun platformunu ve içerik türünü belirle. Türkçe viral analiz yap.
Sadece şu satırları yaz:

PUAN: 75
KARAR: Yüksek Viral Potansiyel
DEGERLENDIRME: 2-3 cümle değerlendirme.
ICERIK: İçerik özeti.
HOOK: 80
TUTULMA: 65
TEMPO: 70
GORSEL: 75
CTA: 50
TREND: 85
GUC1: Güçlü yön.
GUC2: Güçlü yön.
SORUN1: Sorun.
SORUN2: Sorun.
DIKKAT: Dikkat noktası.
ONERI1: Öneri.
ONERI2: Öneri.
ONERI3: Öneri.
ONERI4: Öneri.
ONERI5: Öneri.`;

  const msg = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1024,
    messages: [{ role: "user", content: prompt }],
  });

  const raw = msg.content[0].text;
  const get = (key) => {
    const re = new RegExp(`${key}:\\s*(.+?)(?=\\n[A-Z0-9]+:|$)`, "si");
    const m = raw.match(re);
    return (m ? m[1] : "").trim();
  };
  const num = (key) => {
    const n = parseInt((get(key).match(/\d+/) || ["60"])[0]);
    return Math.min(100, Math.max(0, isNaN(n) ? 60 : n));
  };
  const lv = (v) => v >= 70 ? "iyi" : v >= 40 ? "orta" : "zayıf";
  const h=num("HOOK"),tu=num("TUTULMA"),te=num("TEMPO"),g=num("GORSEL"),c=num("CTA"),tr=num("TREND");

  return {
    score: num("PUAN"),
    verdict: get("KARAR") || "Orta Viral Potansiyel",
    verdictDesc: get("DEGERLENDIRME"),
    transcript: get("ICERIK"),
    metrics: [
      {name:"Hook Gücü (İlk 3 sn)",value:h,level:lv(h)},
      {name:"İzlenme Tutulma",value:tu,level:lv(tu)},
      {name:"Tempo & Ritim",value:te,level:lv(te)},
      {name:"Görsel Kalite",value:g,level:lv(g)},
      {name:"CTA Gücü",value:c,level:lv(c)},
      {name:"Trend Uyumu",value:tr,level:lv(tr)},
    ],
    viralFactors: [
      {type:"pos",badge:"GÜÇ",text:get("GUC1")},
      {type:"pos",badge:"GÜÇ",text:get("GUC2")},
      {type:"neg",badge:"SORUN",text:get("SORUN1")},
      {type:"neg",badge:"SORUN",text:get("SORUN2")},
      {type:"neu",badge:"DİKKAT",text:get("DIKKAT")},
    ],
    suggestions: [get("ONERI1"),get("ONERI2"),get("ONERI3"),get("ONERI4"),get("ONERI5")].filter(Boolean),
  };
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Pulse API port ${PORT} aktif`));
